<footer class="footer_class">
    Made with passion by Twana Daniel</br>
    Powered by <a href="https://www.bluemix.net" target="_blank">IBM Bluemix.</a>
    Check out our source code on <a href="https://github.com/IBM-Bluemix/CRUD-PHP-Codeigniter-Bluemix" target="_blank">GitHub.</a>
</footer>