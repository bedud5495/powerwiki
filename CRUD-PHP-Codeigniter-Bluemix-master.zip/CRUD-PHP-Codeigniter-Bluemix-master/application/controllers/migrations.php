<?php

//if ( PHP_SAPI !== 'cli' ) exit('No web access allowed');

class Migrations extends CI_Controller {
    public function index() {

    }
}

?>
